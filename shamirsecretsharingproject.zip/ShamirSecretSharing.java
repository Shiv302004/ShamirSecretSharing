import java.util.*;
import java.io.*;

public class ShamirSecretSharing {
    public static void main(String[] args) throws Exception {
        // Step 1: Read the input JSON file (this could be replaced with reading from a String or file)
        String jsonString = readFile("input.json");

        // Step 2: Parse the JSON string manually
        Map<String, Object> json = parseJson(jsonString);

        // Step 3: Extract 'keys' section and validate
        Map<String, Object> keys = (Map<String, Object>) json.get("keys");
        if (keys == null) {
            throw new NullPointerException("The 'keys' section is missing from the JSON input.");
        }
        int n = Integer.parseInt(keys.get("n").toString());
        int k = Integer.parseInt(keys.get("k").toString());

        // Step 4: Decode points (x, y pairs)
        List<Point> points = new ArrayList<>();
        for (Map.Entry<String, Object> entry : json.entrySet()) {
            if (!entry.getKey().equals("keys")) {
                Map<String, Object> pointData = (Map<String, Object>) entry.getValue();
                int x = Integer.parseInt(entry.getKey());
                int base = Integer.parseInt(pointData.get("base").toString());
                String value = pointData.get("value").toString();
                int y = Integer.parseInt(value, base); // Decode y using the base
                points.add(new Point(x, y));
            }
        }

        // Step 5: Find the constant term (c) using Lagrange interpolation
        double constantTerm = calculateConstantTerm(points, k);
        System.out.println("Secret (Constant Term): " + (int) constantTerm);
    }

    // Method to read the input file
    private static String readFile(String fileName) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line.trim());
            }
        }
        return sb.toString();
    }

    // Simple method to parse JSON-like string into a Map (without using libraries)
    private static Map<String, Object> parseJson(String jsonString) {
        Map<String, Object> resultMap = new HashMap<>();
        jsonString = jsonString.replaceAll("[{}\"]", "");  // Remove curly braces and quotes
        String[] parts = jsonString.split(",");
        for (String part : parts) {
            String[] keyValue = part.split(":");
            if (keyValue.length == 2) {
                String key = keyValue[0].trim();
                String value = keyValue[1].trim();
                if (key.equals("keys")) {
                    Map<String, Object> keysMap = new HashMap<>();
                    String[] keyParts = value.split(",");
                    for (String keyPart : keyParts) {
                        String[] keyValuePair = keyPart.split(":");
                        keysMap.put(keyValuePair[0].trim(), keyValuePair[1].trim());
                    }
                    resultMap.put("keys", keysMap);
                } else {
                    resultMap.put(key, value);
                }
            }
        }
        return resultMap;
    }

    // Method to calculate the constant term (c) using Lagrange interpolation
    private static double calculateConstantTerm(List<Point> points, int k) {
        double constant = 0.0;

        // Use only the first 'k' points for interpolation
        for (int i = 0; i < k; i++) {
            double term = points.get(i).y;
            for (int j = 0; j < k; j++) {
                if (i != j) {
                    term *= ((double) 0 - points.get(j).x) / (points.get(i).x - points.get(j).x);
                }
            }
            constant += term;
        }

        return constant;
    }

    // Point class to store x and y coordinates
    static class Point {
        int x, y;

        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
}
